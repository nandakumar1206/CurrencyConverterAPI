﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Text.Json;

namespace CurrencyConverterAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CurrencyConverterController : ControllerBase
    {
        private const string InvalidRequest = "Invalid Request URL | Kindly input Source / Target Currency in request Endpoint";
        private const string InvalidAmount = "Kindly input a valid amount for conversion";

        private readonly Dictionary<string, decimal> exchangeRates;
        private readonly ILogger<CurrencyConverterController> _logger;

        public CurrencyConverterController(ILogger<CurrencyConverterController> logger)
        {
            _logger = logger;
            exchangeRates = LoadExchangeRates();
        }


        private Dictionary<string, decimal> LoadExchangeRates()
        {
            try
            {
                // Load the exchange rates from static exchangeRates file
                string exchangeRatesJson = System.IO.File.ReadAllText("exchangeRates.json");
                var rates = JsonSerializer.Deserialize<Dictionary<string, decimal>>(exchangeRatesJson);

                // Override exchange rates with environment variables if available first preference given to UserEnv Variables then SystemEnv
                foreach (string key in rates.Keys)
                {
                    string envVarSystem = Environment.GetEnvironmentVariable(key, EnvironmentVariableTarget.Machine);
                    string envVarUser = Environment.GetEnvironmentVariable(key, EnvironmentVariableTarget.User);

                    if (!string.IsNullOrEmpty(envVarUser) && decimal.TryParse(envVarUser, out decimal userRate))
                    {
                        _logger.LogInformation($"envVar found in UserEnvVaribales - key {key} rate {envVarUser}");
                        rates[key] = userRate;
                    }

                    else if (!string.IsNullOrEmpty(envVarSystem) && decimal.TryParse(envVarSystem, out decimal rate))
                    {
                        _logger.LogInformation($"envVar found in SystemEnvVaribales - key {key} rate {envVarSystem}");
                        rates[key] = rate;
                    }
                }

                return rates;
            }
            catch (FileNotFoundException ex)
            {
                _logger.LogError($"Exchange rates file not found: {ex.Message}");
                return null;
            }
            catch (Exception ex)
            {
                _logger.LogError($"An error occurred while loading exchange rates: {ex.Message}");
                return null;
            }
        }

        [HttpGet("/convert")]
        public IActionResult ConvertCurrency(string? sourceCurrency, string? targetCurrency, decimal amount)
        {
            if (exchangeRates == null)
            {
                return StatusCode(500, "Exchange rates are not available. Please try again later.");
            }

            _logger.LogInformation($"Received request: sourceCurrency={sourceCurrency}, targetCurrency={targetCurrency}, amount={amount}");
            // If query parameters are not provided, return exchange rates
            if (string.IsNullOrWhiteSpace(sourceCurrency) || string.IsNullOrWhiteSpace(targetCurrency))
            {
                _logger.LogInformation($"Either sourceCurrency/targetCurrency are empty or both");
                return Ok( new
                {
                    InvalidRequest,
                    exchangeRates
                }
                );
            }

            _logger.LogInformation($"Converting {amount} {sourceCurrency} to {targetCurrency}.");

            // Validate the currency pair
            string currencyPairKey = $"{sourceCurrency.ToUpper()}_TO_{targetCurrency.ToUpper()}";
            if (!exchangeRates.ContainsKey(currencyPairKey))
            {
                _logger.LogWarning($"{sourceCurrency}-{targetCurrency} Inputted currency pair is not supported.");
                return BadRequest("Inputted Curreny pair is unsupported, Kindly input a valid currency pair USD/INR/EUR");
            }

            if (amount <= 0)
            {
                _logger.LogInformation($"Inputted amount value {amount} is invalid ");
                return Ok(InvalidAmount);
            }

            decimal exchangeRate = exchangeRates[currencyPairKey];
            decimal convertedAmount = amount * exchangeRate;

            return Ok(new
            {
                exchangeRate,
                convertedAmount
            });
        }
    }
}

