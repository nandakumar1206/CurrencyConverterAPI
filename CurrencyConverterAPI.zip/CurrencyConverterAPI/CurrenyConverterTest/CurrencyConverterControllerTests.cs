using Microsoft.AspNetCore.Mvc;
using NUnit.Framework;
using Moq;
using CurrencyConverterAPI.Controllers;
using Microsoft.Extensions.Logging;

namespace CurrenyConverterTest
{
    public class CurrencyConverterControllerTests
    {
        private readonly ILogger<CurrencyConverterController> _logger;

        [Test]
        public void ConvertCurrency_ValidInput_from_exchangeRateJsonFile()
        {
            var loggerMock = new Mock<ILogger<CurrencyConverterController>>();
            var controller = new CurrencyConverterController(loggerMock.Object);
            string sourceCurrency = "USD";
            string targetCurrency = "EUR";
            decimal amount = 100;

            var result = controller.ConvertCurrency(sourceCurrency, targetCurrency, amount) as OkObjectResult;

            Assert.That(result.Value, Has.Property("convertedAmount").EqualTo(85.00));
        }

        [Test]
        public void ConvertCurrency_InvalidCurrency()
        {
            var loggerMock = new Mock<ILogger<CurrencyConverterController>>();
            var controller = new CurrencyConverterController(loggerMock.Object);
            string sourceCurrency = "ABC"; // Invalid currency
            string targetCurrency = "EUR";
            decimal amount = 100;

            var result = controller.ConvertCurrency(sourceCurrency, targetCurrency, amount);

            Assert.That(result, Is.InstanceOf<BadRequestObjectResult>());


        }

        [Test]
        public void ConvertCurrency_RateFromEnvVariable()
        {
            Environment.SetEnvironmentVariable("USD_TO_EUR", "1.00", EnvironmentVariableTarget.User);
            var loggerMock = new Mock<ILogger<CurrencyConverterController>>();
            var controller = new CurrencyConverterController(loggerMock.Object);
            string sourceCurrency = "USD";
            string targetCurrency = "EUR";
            decimal amount = 100;

            var result = controller.ConvertCurrency(sourceCurrency, targetCurrency, amount) as OkObjectResult;

            Assert.That(result.Value, Has.Property("exchangeRate").EqualTo(1.00));
            Assert.That(result.Value, Has.Property("convertedAmount").EqualTo(100.00));
            Environment.SetEnvironmentVariable("USD_TO_EUR", null, EnvironmentVariableTarget.User);

        }
    }
}
